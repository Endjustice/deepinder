// 📁 src/monitor.js - کامل و اصلاح شده
export default {
  async scheduled(event, env, ctx) {
    const sitesToMonitor = [
      'https://alizadeh-stationery.ir',
      'https://www.alizadeh-stationery.ir'
    ];

    console.log('🔍 Starting site monitoring...');

    for (const site of sitesToMonitor) {
      await ctx.waitUntil(monitorSite(site, env));
    }
  }
};

async function monitorSite(siteUrl, env) {
  try {
    console.log(`Checking ${siteUrl}...`);

    // درخواست با timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 ثانیه

    const response = await fetch(siteUrl, {
      method: 'GET',
      headers: {
        'User-Agent': 'Alizadeh-Auto-Monitor/1.0',
      },
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    const isHealthy = response.status >= 200 && response.status < 400;

    // ذخیره وضعیت در KV
    if (env.DATA_SERVICE) {
      const monitorLog = {
        action: 'site_monitor',
        timestamp: new Date().toISOString(),
        site: siteUrl,
        status: response.status,
        healthy: isHealthy,
        responseTime: Date.now() // می‌توانید زمان پاسخ را اندازه‌گیری کنید
      };

      await env.DATA_SERVICE.fetch('http://internal/data', {
        method: 'POST',
        body: JSON.stringify(monitorLog),
      });
    }

    if (!isHealthy) {
      console.log(`🚨 Site ${siteUrl} is DOWN (Status: ${response.status})`);
      
      // پاک کردن کش اگر سایت مشکل دارد
      if (env.OPS_SERVICE) {
        await env.OPS_SERVICE.fetch('http://internal/purge', {
          method: 'POST',
        });
      }
    } else {
      console.log(`✅ Site ${siteUrl} is UP`);
    }

  } catch (error) {
    console.error(`❌ Monitoring failed for ${siteUrl}:`, error.message);

    // ذخیره خطا
    if (env.DATA_SERVICE) {
      const errorLog = {
        action: 'monitor_error',
        timestamp: new Date().toISOString(),
        site: siteUrl,
        error: error.message,
      };

      await env.DATA_SERVICE.fetch('http://internal/data', {
        method: 'POST',
        body: JSON.stringify(errorLog),
      });
    }

    // پاک کردن کش در صورت خطای شبکه
    if (env.OPS_SERVICE) {
      await env.OPS_SERVICE.fetch('http://internal/purge', {
        method: 'POST',
      });
    }
  }
}
