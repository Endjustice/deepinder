// 📁 src/ops.js - کامل و اصلاح شده
export default {
  async fetch(request, env) {
    // فقط اجازه POST
    if (request.method !== 'POST') {
      return new Response('Method Not Allowed', { status: 405 });
    }

    try {
      // پاک کردن کامل کش Cloudflare
      const purgeResponse = await fetch(
        `https://api.cloudflare.com/client/v4/zones/${env.ZONE_ID}/purge_cache`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${env.CF_API_TOKEN}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ purge_everything: true }),
        }
      );

      const result = await purgeResponse.json();

      // ذخیره لاگ در KV
      if (env.DATA_SERVICE) {
        const logData = {
          action: 'purge_cache',
          timestamp: new Date().toISOString(),
          success: result.success,
          errors: result.errors || [],
        };
        
        try {
          await env.DATA_SERVICE.fetch('http://internal/data', {
            method: 'POST',
            body: JSON.stringify(logData),
          });
        } catch (logError) {
          console.error('Logging failed:', logError);
        }
      }

      return new Response(JSON.stringify(result), {
        status: purgeResponse.status,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
      });

    } catch (error) {
      // خطا به Data Service
      if (env.DATA_SERVICE) {
        const errorLog = {
          action: 'purge_cache_error',
          timestamp: new Date().toISOString(),
          error: error.message,
        };
        
        await env.DATA_SERVICE.fetch('http://internal/data', {
          method: 'POST',
          body: JSON.stringify(errorLog),
        });
      }

      return new Response(
        JSON.stringify({ 
          success: false, 
          errors: [{ message: error.message }] 
        }), 
        { 
          status: 500,
          headers: { 'Content-Type': 'application/json' }
        }
      );
    }
  }
};
