import React, { useState } from 'react';
import { Upload, X } from 'lucide-react';
import { Buffer } from 'buffer';
import { trpc } from '@/lib/trpc';

// Polyfill for Buffer in browser
if (typeof window !== 'undefined' && !window.Buffer) {
  (window as any).Buffer = Buffer;
}

interface FileUploadProps {
  onUploadSuccess?: (url: string, fileKey: string) => void;
  relatedType?: string;
  relatedId?: number;
  accept?: string;
}

export default function FileUpload({
  onUploadSuccess,
  relatedType = 'product',
  relatedId,
  accept = 'image/*'
}: FileUploadProps) {
  const [preview, setPreview] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string>('');
  const uploadMutation = trpc.files.upload.useMutation();

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);

    setFileName(file.name);

    // Upload file
    try {
      const buffer = await file.arrayBuffer();
      const result = await uploadMutation.mutateAsync({
        fileName: file.name,
        fileData: Buffer.from(buffer),
        mimeType: file.type,
        relatedType,
        relatedId,
      });

      if (onUploadSuccess) {
        onUploadSuccess(result.url, result.fileKey);
      }
    } catch (error) {
      console.error('File upload failed:', error);
      setPreview(null);
      setFileName('');
    }
  };

  const handleClear = () => {
    setPreview(null);
    setFileName('');
  };

  return (
    <div className="w-full">
      <div className="border-2 border-dashed border-pink-300 rounded-lg p-6 text-center hover:border-pink-500 transition-colors">
        <label className="cursor-pointer flex flex-col items-center gap-2">
          <Upload className="w-8 h-8 text-pink-500" />
          <span className="text-sm font-medium text-gray-700">
            فایل را اینجا رها کنید یا کلیک کنید
          </span>
          <span className="text-xs text-gray-500">
            {accept === 'image/*' ? 'PNG, JPG, GIF' : 'تمام فرمت‌ها'}
          </span>
          <input
            type="file"
            accept={accept}
            onChange={handleFileChange}
            className="hidden"
            disabled={uploadMutation.isPending}
          />
        </label>
      </div>

      {preview && (
        <div className="mt-4 relative">
          <img
            src={preview}
            alt="Preview"
            className="w-full h-48 object-cover rounded-lg"
          />
          <button
            onClick={handleClear}
            className="absolute top-2 right-2 bg-red-500 text-white p-1 rounded-full hover:bg-red-600"
            disabled={uploadMutation.isPending}
          >
            <X className="w-4 h-4" />
          </button>
          <p className="text-xs text-gray-500 mt-2">{fileName}</p>
        </div>
      )}

      {uploadMutation.isPending && (
        <div className="mt-2 text-center text-sm text-gray-600">
          در حال بارگذاری...
        </div>
      )}

      {uploadMutation.isError && (
        <div className="mt-2 text-center text-sm text-red-600">
          خطا در بارگذاری فایل
        </div>
      )}

      {uploadMutation.isSuccess && (
        <div className="mt-2 text-center text-sm text-green-600">
          فایل با موفقیت بارگذاری شد
        </div>
      )}
    </div>
  );
}
