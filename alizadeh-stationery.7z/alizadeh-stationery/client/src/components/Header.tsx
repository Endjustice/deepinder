import React, { useState } from 'react';
import { ShoppingCart, Search, Heart, Menu, Phone, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';

interface HeaderProps {
  cartCount?: number;
  onCartClick?: () => void;
}

const Header = ({ cartCount = 0, onCartClick }: HeaderProps) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // Handle search
      console.log('Search:', searchQuery);
    }
  };

  const navLinks = [
    { label: 'خانه', href: '/' },
    { label: 'محصولات', href: '/products' },
    { label: 'دسته‌بندی‌ها', href: '/categories' },
    { label: 'درباره ما', href: '/about' },
    { label: 'تماس با ما', href: '/contact' },
  ];

  return (
    <header className="relative bg-gradient-to-r from-pink-100 via-purple-50 to-blue-50 border-b border-pink-200 sticky top-0 z-40">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-4 left-10 w-8 h-8 bg-pink-300 rounded-full opacity-30 animate-bounce"></div>
        <div className="absolute top-8 right-20 w-6 h-6 bg-purple-300 rounded-full opacity-40 animate-pulse"></div>
        <div className="absolute top-12 left-1/3 w-4 h-4 bg-blue-300 rounded-full opacity-35 animate-bounce" style={{ animationDelay: '300ms' }}></div>
        <div className="absolute top-6 right-1/3 w-5 h-5 bg-pink-400 rounded-full opacity-25 animate-pulse" style={{ animationDelay: '500ms' }}></div>
      </div>

      <div className="container mx-auto px-4 py-4 relative z-10">
        <div className="flex items-center justify-between flex-wrap gap-y-4">
          {/* Logo and Brand */}
          <Link href="/" className="flex items-center space-x-2 space-x-reverse">
            <div className="w-10 h-10 bg-gradient-to-br from-pink-400 to-purple-500 rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-lg">پ</span>
            </div>
            <h1 className="text-xl font-bold bg-gradient-to-r from-pink-500 to-purple-600 bg-clip-text text-transparent">
              علیزاده
            </h1>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <a className="text-gray-700 hover:text-pink-500 transition-colors font-medium">
                  {link.label}
                </a>
              </Link>
            ))}
          </nav>

          {/* Phone Number */}
          <div className="hidden lg:flex items-center space-x-2 space-x-reverse text-gray-700">
            <Phone className="w-4 h-4 text-pink-500" />
            <a href="tel:09126909560" className="font-medium hover:text-pink-600 transition">
              09126909560
            </a>
          </div>

          {/* Right Side Actions */}
          <div className="flex items-center space-x-4 space-x-reverse">
            {/* Search Form */}
            <form onSubmit={handleSearchSubmit} className="hidden md:flex items-center bg-white rounded-full px-4 py-2 shadow-sm border border-pink-200">
              <Search className="w-4 h-4 text-gray-400 ml-2" />
              <input 
                type="text" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="جستجو..." 
                className="bg-transparent outline-none text-sm w-48 text-right"
              />
            </form>

            {/* Favorites Button */}
            <Button variant="ghost" size="sm" className="relative">
              <Heart className="w-5 h-5 text-pink-500" />
              <span className="absolute -top-1 -right-1 bg-pink-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">0</span>
            </Button>

            {/* Shopping Cart Button */}
            <Button 
              variant="ghost" 
              size="sm" 
              className="relative"
              onClick={onCartClick}
            >
              <ShoppingCart className="w-5 h-5 text-purple-500" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-purple-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Button>

            {/* Mobile Menu Button */}
            <Button 
              variant="ghost" 
              size="sm" 
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? (
                <X className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 pt-4 border-t border-pink-200 space-y-2">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <a 
                  className="block text-gray-700 hover:text-pink-500 transition-colors font-medium py-2"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {link.label}
                </a>
              </Link>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;
