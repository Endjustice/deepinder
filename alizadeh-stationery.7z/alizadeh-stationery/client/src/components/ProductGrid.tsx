import React from 'react';
import ProductCard from './ProductCard';
import { SlideUp } from './ScrollAnimations';

// Import product images
import penCaseImage from '@/assets/3522.jpg';
import rabbitPensImage from '@/assets/3524.jpg';
import compassSetImage from '@/assets/3527.jpg';
import notebooksImage from '@/assets/3525.jpg';
import artSuppliesImage from '@/assets/3526.jpg';
import bottlesImage from '@/assets/3529.jpg';

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  rating: number;
  image: string;
  category: string;
  onSale?: boolean;
}

interface ProductGridProps {
  selectedFilter?: string;
  onAddToCart?: (product: Product) => void;
}

const ProductGrid = ({ selectedFilter = 'all', onAddToCart }: ProductGridProps) => {
  const products: Product[] = [
    {
      id: 1,
      name: 'جامدادی‌های فانتزی استیچ',
      description: 'مجموعه‌ای از جامدادی‌های رنگارنگ با طرح‌های محبوب کارتونی',
      price: 85000,
      originalPrice: 120000,
      rating: 4.8,
      image: penCaseImage,
      category: 'pencilcase',
      onSale: true
    },
    {
      id: 2,
      name: 'خودکارهای خرگوشی پاستیلی',
      description: 'خودکارهای شیرین با طرح خرگوش‌های بامزه در رنگ‌های پاستیلی',
      price: 45000,
      rating: 4.9,
      image: rabbitPensImage,
      category: 'pencil',
      onSale: false
    },
    {
      id: 3,
      name: 'ست پرگار و خط‌کش',
      description: 'ست کامل ابزار هندسی با طراحی مدرن و رنگ‌های شاد',
      price: 95000,
      originalPrice: 130000,
      rating: 4.7,
      image: compassSetImage,
      category: 'geometry',
      onSale: true
    },
    {
      id: 4,
      name: 'دفترهای لابوبو',
      description: 'دفترهای فانتزی با جلد سخت و طرح‌های منحصر به فرد',
      price: 65000,
      rating: 4.6,
      image: notebooksImage,
      category: 'notebook',
      onSale: false
    },
    {
      id: 5,
      name: 'مجموعه نقاشی حرفه‌ای',
      description: 'ست کامل مداد رنگی و پاستل روغنی برای هنرمندان',
      price: 180000,
      originalPrice: 250000,
      rating: 4.9,
      image: artSuppliesImage,
      category: 'marker',
      onSale: true
    },
    {
      id: 6,
      name: 'بطری‌های آب فانتزی',
      description: 'بطری‌های شیشه‌ای با طرح‌های کارتونی و رنگ‌های شاد',
      price: 75000,
      rating: 4.5,
      image: bottlesImage,
      category: 'decorative',
      onSale: false
    }
  ];

  // Filter products based on selected filter
  const filteredProducts = selectedFilter === 'all' 
    ? products 
    : products.filter(product => product.category === selectedFilter);

  return (
    <SlideUp>
      <section className="py-16 bg-gradient-to-b from-white to-pink-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">
              <span className="bg-gradient-to-r from-pink-500 to-purple-600 bg-clip-text text-transparent">
                محبوب‌ترین محصولات
              </span>
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              مجموعه‌ای منتخب از بهترین و محبوب‌ترین لوازم‌تحریر فانتزی که مورد علاقه مشتریان عزیز ما هستند
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts.map(product => (
              <ProductCard 
                key={product.id} 
                product={product}
                onAddToCart={onAddToCart}
              />
            ))}
          </div>
          
          {filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">محصولی در این دسته‌بندی یافت نشد.</p>
            </div>
          )}
          
          <div className="text-center mt-12">
            <button className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white px-8 py-3 rounded-full text-lg font-medium shadow-lg hover:shadow-xl transition-all duration-300">
              مشاهده همه محصولات
            </button>
          </div>
        </div>
      </section>
    </SlideUp>
  );
};

export default ProductGrid;
