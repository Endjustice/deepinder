import React from 'react';
import { Heart, ShoppingCart, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  rating: number;
  image: string;
  category: string;
  onSale?: boolean;
}

interface ProductCardProps {
  product: Product;
  onAddToCart?: (product: Product) => void;
}

const ProductCard = ({ product, onAddToCart }: ProductCardProps) => {
  return (
    <div className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 overflow-hidden border border-pink-100 hover:border-pink-300 transform hover:-translate-y-2 hover:scale-105">
      {/* Product Image */}
      <div className="relative overflow-hidden bg-gradient-to-br from-pink-50 to-purple-50 aspect-square">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-125 transition-transform duration-700"
        />
        
        {/* Price overlay on hover */}
        <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <div className="text-center text-white transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
            <div className="text-2xl font-bold mb-2">
              {product.price.toLocaleString('fa-IR')} تومان
            </div>
            {product.originalPrice && (
              <div className="text-lg line-through opacity-75">
                {product.originalPrice.toLocaleString('fa-IR')} تومان
              </div>
            )}
          </div>
        </div>
        
        {/* Favorite Button */}
        <button className="absolute top-3 right-3 w-8 h-8 bg-white rounded-full shadow-md flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-pink-50">
          <Heart className="w-4 h-4 text-pink-500" />
        </button>
        
        {/* Sale Badge */}
        {product.onSale && (
          <div className="absolute top-3 left-3 bg-gradient-to-r from-pink-500 to-purple-600 text-white px-2 py-1 rounded-full text-xs font-medium">
            تخفیف ویژه
          </div>
        )}
      </div>
      
      {/* Product Info */}
      <div className="p-4">
        <h3 className="font-bold text-gray-800 mb-2 text-right group-hover:text-pink-600 transition-colors">
          {product.name}
        </h3>
        
        <p className="text-sm text-gray-600 mb-3 text-right leading-relaxed line-clamp-2">
          {product.description}
        </p>
        
        {/* Rating */}
        <div className="flex items-center justify-end mb-3">
          <span className="text-sm text-gray-600 mr-1">{product.rating}</span>
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <Star 
                key={i} 
                className={`w-4 h-4 ${i < Math.floor(product.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
              />
            ))}
          </div>
        </div>
        
        {/* Price and Add to Cart */}
        <div className="flex items-center justify-between">
          <Button 
            size="sm" 
            className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white rounded-full px-4 py-2 text-sm font-medium shadow-md hover:shadow-lg transition-all duration-300"
            onClick={() => onAddToCart?.(product)}
          >
            <ShoppingCart className="w-4 h-4 ml-1" />
            افزودن
          </Button>
          
          <div className="text-right">
            {product.originalPrice && (
              <span className="text-sm text-gray-400 line-through block">
                {product.originalPrice.toLocaleString('fa-IR')} تومان
              </span>
            )}
            <span className="text-lg font-bold text-pink-600">
              {product.price.toLocaleString('fa-IR')} تومان
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
