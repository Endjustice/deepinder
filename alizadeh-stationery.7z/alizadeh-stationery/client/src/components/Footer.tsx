import React from 'react';
import { Instagram, Send, Phone, MapPin, Mail, Heart } from 'lucide-react';
import { Link } from 'wouter';

const CONTACT_INFO = {
  email: "info@alizadeh-stationery.ir",
  phones: [
    { label: "0263666603", href: "tel:0263666603", type: "تلفن ثابت" },
    { label: "02636636177", href: "tel:02636636177", type: "تلفن ثابت" },
    { label: "0263663798", href: "tel:0263663798", type: "تلفن ثابت" },
    { label: "09126909560", href: "tel:09126909560", type: "همراه" }
  ],
  mapCoords: "35.750778,51.002567"
};

const Footer = () => {
  return (
    <footer className="bg-gradient-to-br from-gray-900 via-purple-900 to-pink-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="text-center md:text-right">
            <div className="flex items-center justify-center md:justify-start space-x-2 space-x-reverse mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-pink-400 to-purple-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-lg">پ</span>
              </div>
              <h3 className="text-xl font-bold bg-gradient-to-r from-pink-300 to-purple-300 bg-clip-text text-transparent">
                علیزاده
              </h3>
            </div>
            <p className="text-gray-300 leading-relaxed mb-4">
              فروشگاه تخصصی لوازم‌تحریر علیزاده. جایی که خلاقیت شما شکل می‌گیرد.
            </p>
            <div className="flex justify-center md:justify-start space-x-4 space-x-reverse">
              <a href="#" className="w-10 h-10 bg-pink-600 rounded-full flex items-center justify-center hover:bg-pink-700 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center hover:bg-blue-700 transition-colors">
                <Send className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="text-center md:text-right">
            <h4 className="text-lg font-bold mb-4 text-pink-300">دسترسی سریع</h4>
            <ul className="space-y-2">
              <li><Link href="/"><a className="text-gray-300 hover:text-pink-300 transition-colors">صفحه اصلی</a></Link></li>
              <li><Link href="/products"><a className="text-gray-300 hover:text-pink-300 transition-colors">محصولات</a></Link></li>
              <li><Link href="/categories"><a className="text-gray-300 hover:text-pink-300 transition-colors">دسته‌بندی‌ها</a></Link></li>
              <li><Link href="/about"><a className="text-gray-300 hover:text-pink-300 transition-colors">درباره ما</a></Link></li>
            </ul>
          </div>

          {/* Customer Service */}
          <div className="text-center md:text-right">
            <h4 className="text-lg font-bold mb-4 text-purple-300">خدمات مشتریان</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-purple-300 transition-colors">راهنمای خرید</a></li>
              <li><a href="#" className="text-gray-300 hover:text-purple-300 transition-colors">شرایط و قوانین</a></li>
              <li><a href="#" className="text-gray-300 hover:text-purple-300 transition-colors">حریم خصوصی</a></li>
              <li><a href="#" className="text-gray-300 hover:text-purple-300 transition-colors">پرسش‌های متداول</a></li>
              <li><Link href="/contact"><a className="text-gray-300 hover:text-purple-300 transition-colors">تماس با ما</a></Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="text-center md:text-right">
            <h4 className="text-lg font-bold mb-4 text-pink-300">اطلاعات تماس</h4>
            <div className="space-y-3">
              {CONTACT_INFO.phones.map((phone, index) => (
                <div key={index} className="flex items-center justify-center md:justify-start space-x-2 space-x-reverse">
                  <Phone className="w-5 h-5 text-pink-300" />
                  <a href={phone.href} className="text-gray-300 hover:text-pink-400 transition text-sm">
                    {phone.label}
                  </a>
                </div>
              ))}
              <div className="flex items-center justify-center md:justify-start space-x-2 space-x-reverse">
                <Mail className="w-5 h-5 text-pink-300" />
                <a href={`mailto:${CONTACT_INFO.email}`} className="text-gray-300 hover:text-pink-400 transition text-sm">
                  {CONTACT_INFO.email}
                </a>
              </div>
              <div className="flex items-center justify-center md:justify-start space-x-2 space-x-reverse">
                <MapPin className="w-5 h-5 text-pink-300" />
                <a href={`https://maps.google.com/?q=${CONTACT_INFO.mapCoords}`} target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-pink-400 transition text-sm">
                  مشاهده نقشه
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-400 flex items-center justify-center space-x-1 space-x-reverse">
            <span>ساخته شده با</span>
            <Heart className="w-4 h-4 text-pink-400 fill-current" />
            <span>برای شما</span>
          </p>
          <p className="text-gray-500 text-sm mt-2">
            تمامی حقوق محفوظ است © 1403 - پخش لوازم‌التحریر علیزاده
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
