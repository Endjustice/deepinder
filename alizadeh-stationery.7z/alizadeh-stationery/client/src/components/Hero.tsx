import React from 'react';
import { Button } from '@/components/ui/button';
import { Sparkles, Star, Heart } from 'lucide-react';
import { Link } from 'wouter';

const Hero = () => {
  return (
    <section className="relative py-16 overflow-hidden min-h-screen flex items-center">
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-pink-100/80 via-purple-100/80 to-blue-100/80"></div>
      
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 animate-float">
          <Sparkles className="w-8 h-8 text-pink-400 opacity-60" />
        </div>
        <div className="absolute top-32 right-16 animate-float" style={{ animationDelay: '1000ms' }}>
          <Star className="w-6 h-6 text-purple-400 opacity-50" />
        </div>
        <div className="absolute bottom-20 left-1/4 animate-float" style={{ animationDelay: '2000ms' }}>
          <Heart className="w-7 h-7 text-blue-400 opacity-40" />
        </div>
        <div className="absolute top-40 right-1/3 animate-float" style={{ animationDelay: '500ms' }}>
          <Sparkles className="w-5 h-5 text-pink-500 opacity-70" />
        </div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div className="text-center md:text-right">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 leading-tight gradient-text">
              پخش لوازم‌التحریر علیزاده
            </h2>
            
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              مجموعه‌ای منحصر به فرد از لوازم‌تحریر فانتزی و پاستیلی که خلاقیت شما را بی‌حد و حصر می‌کند. 
              از دفترهای رنگارنگ تا خودکارهای جادویی، همه چیز برای شادی و الهام شما.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <Link href="/products">
                <Button className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white px-8 py-3 rounded-full text-lg font-medium shadow-lg hover:shadow-xl transition-all duration-300">
                  مشاهده محصولات
                </Button>
              </Link>
              <Link href="/about">
                <Button variant="outline" className="border-2 border-pink-300 text-pink-600 hover:bg-pink-50 px-8 py-3 rounded-full text-lg font-medium">
                  درباره ما
                </Button>
              </Link>
            </div>
          </div>

          {/* Image/Product Showcase */}
          <div className="relative">
            <div className="bg-white rounded-3xl p-8 shadow-2xl transform hover:scale-105 transition-transform duration-500">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gradient-to-br from-pink-100 to-pink-200 rounded-2xl p-4 aspect-square flex items-center justify-center">
                  <div className="w-16 h-16 bg-pink-400 rounded-full flex items-center justify-center">
                    <span className="text-white text-2xl">📝</span>
                  </div>
                </div>
                <div className="bg-gradient-to-br from-purple-100 to-purple-200 rounded-2xl p-4 aspect-square flex items-center justify-center">
                  <div className="w-16 h-16 bg-purple-400 rounded-full flex items-center justify-center">
                    <span className="text-white text-2xl">✏️</span>
                  </div>
                </div>
                <div className="bg-gradient-to-br from-blue-100 to-blue-200 rounded-2xl p-4 aspect-square flex items-center justify-center">
                  <div className="w-16 h-16 bg-blue-400 rounded-full flex items-center justify-center">
                    <span className="text-white text-2xl">📚</span>
                  </div>
                </div>
                <div className="bg-gradient-to-br from-yellow-100 to-yellow-200 rounded-2xl p-4 aspect-square flex items-center justify-center">
                  <div className="w-16 h-16 bg-yellow-400 rounded-full flex items-center justify-center">
                    <span className="text-white text-2xl">🎨</span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Floating elements */}
            <div className="absolute -top-4 -right-4 w-12 h-12 bg-pink-400 rounded-full opacity-80 animate-bounce"></div>
            <div className="absolute -bottom-4 -left-4 w-8 h-8 bg-purple-400 rounded-full opacity-70 animate-pulse"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
