import React from 'react';

const FloatingElements = () => {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {/* Floating circles */}
      <div className="absolute top-20 left-10 w-8 h-8 bg-pink-300 rounded-full opacity-30 animate-float"></div>
      <div className="absolute top-32 right-16 w-6 h-6 bg-purple-300 rounded-full opacity-40 animate-pulse"></div>
      <div className="absolute bottom-40 left-1/4 w-4 h-4 bg-blue-300 rounded-full opacity-35 animate-float" style={{ animationDelay: '300ms' }}></div>
      <div className="absolute top-40 right-1/3 w-5 h-5 bg-pink-400 rounded-full opacity-25 animate-pulse" style={{ animationDelay: '500ms' }}></div>
      
      {/* Additional floating elements */}
      <div className="absolute bottom-20 right-10 w-6 h-6 bg-purple-200 rounded-full opacity-20 animate-float" style={{ animationDelay: '1000ms' }}></div>
      <div className="absolute top-1/2 left-1/3 w-3 h-3 bg-blue-200 rounded-full opacity-25 animate-pulse" style={{ animationDelay: '700ms' }}></div>
    </div>
  );
};

export default FloatingElements;
