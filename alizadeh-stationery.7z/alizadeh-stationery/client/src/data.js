// 📁 src/data.js - کامل و اصلاح شده
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;

    try {
      // Routes
      if (request.method === 'POST' && path === '/data') {
        return await handleStoreData(request, env);
      }

      if (request.method === 'GET' && path === '/logs') {
        return await handleGetLogs(request, env);
      }

      if (path === '/health') {
        return new Response(JSON.stringify({ status: 'healthy' }), {
          headers: { 'Content-Type': 'application/json' }
        });
      }

      // Default
      return new Response(JSON.stringify({ 
        service: 'Alizadeh Data Service',
        status: 'operational'
      }), {
        headers: { 'Content-Type': 'application/json' }
      });

    } catch (error) {
      return new Response(
        JSON.stringify({ error: error.message }), 
        { 
          status: 500,
          headers: { 'Content-Type': 'application/json' }
        }
      );
    }
  }
};

// ذخیره داده در KV
async function handleStoreData(request, env) {
  const data = await request.json();
  
  // ایجاد کلید منحصر به فرد بر اساس timestamp
  const timestamp = data.timestamp || new Date().toISOString();
  const key = `log_${timestamp}_${Math.random().toString(36).substr(2, 9)}`;
  
  // ذخیره در KV
  await env.LOGS_KV.put(key, JSON.stringify({
    ...data,
    storedAt: new Date().toISOString(),
    id: key
  }));

  return new Response(
    JSON.stringify({ 
      success: true, 
      message: 'Data stored successfully',
      key: key 
    }), 
    { 
      headers: { 'Content-Type': 'application/json' } 
    }
  );
}

// دریافت لاگ‌ها از KV
async function handleGetLogs(request, env) {
  const { keys } = await env.LOGS_KV.list();
  
  const logs = [];
  for (const key of keys) {
    const value = await env.LOGS_KV.get(key);
    if (value) {
      logs.push(JSON.parse(value));
    }
  }

  // مرتب سازی بر اساس timestamp
  logs.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

  // محدود کردن به 50 آیتم آخر
  const recentLogs = logs.slice(0, 50);

  return new Response(
    JSON.stringify({
      count: recentLogs.length,
      logs: recentLogs
    }), 
    { 
      headers: { 'Content-Type': 'application/json' } 
    }
  );
}
