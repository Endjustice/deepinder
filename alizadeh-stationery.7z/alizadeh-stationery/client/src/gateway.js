// 📁 src/gateway.js - کامل و اصلاح شده
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;

    // CORS headers
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, X-Auth',
    };

    // Handle preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    // Routes
    if (path === '/purge' || url.searchParams.get('cmd') === 'purge') {
      return handlePurge(request, env, corsHeaders);
    }

    if (path === '/status') {
      return handleStatus(request, env, corsHeaders);
    }

    if (path === '/logs') {
      return handleLogs(request, env, corsHeaders);
    }

    // Default route
    return new Response(
      JSON.stringify({
        service: 'Alizadeh Gateway',
        status: 'operational',
        endpoints: {
          '/purge?cmd=purge': 'Purge cache (requires X-Auth header)',
          '/status': 'Service status',
          '/logs': 'View logs (requires X-Auth header)'
        }
      }),
      { 
        headers: { 
          'Content-Type': 'application/json',
          ...corsHeaders 
        } 
      }
    );
  }
};

// پاک کردن کش
async function handlePurge(request, env, corsHeaders) {
  // احراز هویت
  const authHeader = request.headers.get('X-Auth');
  if (authHeader !== env.MY_SECRET_PASS) {
    return new Response(
      JSON.stringify({ error: '⛔ Access Denied - Invalid X-Auth header' }),
      { 
        status: 403,
        headers: { 
          'Content-Type': 'application/json',
          ...corsHeaders 
        } 
      }
    );
  }

  try {
    const purgeResult = await env.OPS_SERVICE.fetch('http://internal/purge', {
      method: 'POST',
    });

    const result = await purgeResult.json();

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Cache purge initiated',
        result: result
      }),
      { 
        headers: { 
          'Content-Type': 'application/json',
          ...corsHeaders 
        } 
      }
    );

  } catch (error) {
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message
      }),
      { 
        status: 500,
        headers: { 
          'Content-Type': 'application/json',
          ...corsHeaders 
        } 
      }
    );
  }
}

// وضعیت سرویس
async function handleStatus(request, env, corsHeaders) {
  const status = {
    gateway: 'operational',
    timestamp: new Date().toISOString(),
    services: {
      ops: 'unknown',
      data: 'unknown',
      monitor: 'active'
    }
  };

  // بررسی وضعیت OPS
  try {
    await env.OPS_SERVICE.fetch('http://internal/health');
    status.services.ops = 'operational';
  } catch (error) {
    status.services.ops = 'degraded';
  }

  // بررسی وضعیت DATA
  try {
    await env.DATA_SERVICE.fetch('http://internal/health');
    status.services.data = 'operational';
  } catch (error) {
    status.services.data = 'degraded';
  }

  return new Response(
    JSON.stringify(status),
    { 
      headers: { 
        'Content-Type': 'application/json',
        ...corsHeaders 
      } 
    }
  );
}

// مشاهده لاگ‌ها
async function handleLogs(request, env, corsHeaders) {
  const authHeader = request.headers.get('X-Auth');
  if (authHeader !== env.MY_SECRET_PASS) {
    return new Response(
      JSON.stringify({ error: '⛔ Access Denied' }),
      { 
        status: 403,
        headers: { 
          'Content-Type': 'application/json',
          ...corsHeaders 
        } 
      }
    );
  }

  try {
    const logsResponse = await env.DATA_SERVICE.fetch('http://internal/logs');
    const logs = await logsResponse.json();

    return new Response(
      JSON.stringify(logs),
      { 
        headers: { 
          'Content-Type': 'application/json',
          ...corsHeaders 
        } 
      }
    );

  } catch (error) {
    return new Response(
      JSON.stringify({ error: 'Failed to fetch logs' }),
      { 
        status: 500,
        headers: { 
          'Content-Type': 'application/json',
          ...corsHeaders 
        } 
      }
    );
  }
}
