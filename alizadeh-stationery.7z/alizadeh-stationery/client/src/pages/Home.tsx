import React, { useState, useEffect } from 'react';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import ProductGrid from '@/components/ProductGrid';
import ContactForm from '@/components/ContactForm';
import Footer from '@/components/Footer';
import ScrollProgressBar from '@/components/ScrollProgressBar';
import FloatingElements from '@/components/FloatingElements';
import { FadeIn, SlideUp } from '@/components/ScrollAnimations';

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
}

export default function Home() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedFilter, setSelectedFilter] = useState('all');

  // Load cart from localStorage on mount
  useEffect(() => {
    const savedCart = localStorage.getItem('alizadeh-cart');
    if (savedCart) {
      setCart(JSON.parse(savedCart));
    }
  }, []);

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('alizadeh-cart', JSON.stringify(cart));
  }, [cart]);

  const handleAddToCart = (product: any) => {
    const existingItem = cart.find(item => item.id === product.id);
    
    if (existingItem) {
      setCart(cart.map(item =>
        item.id === product.id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setCart([...cart, {
        id: product.id,
        name: product.name,
        price: product.price,
        quantity: 1
      }]);
    }
  };

  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);

  return (
    <div className="min-h-screen bg-white relative">
      <ScrollProgressBar />
      <FloatingElements />
      
      <div className="relative z-10">
        <Header cartCount={cartCount} />

        <main>
          <Hero />
          
          <FadeIn>
            <section className="py-16 bg-white">
              <div className="container mx-auto px-4">
                <div className="text-center mb-12">
                  <h2 className="text-4xl font-bold text-gray-800 mb-4">
                    <span className="bg-gradient-to-r from-pink-500 to-purple-600 bg-clip-text text-transparent">
                      دسته‌بندی محصولات
                    </span>
                  </h2>
                </div>
                <div className="flex flex-wrap justify-center gap-4">
                  {[
                    { id: 'all', label: 'همه' },
                    { id: 'pencilcase', label: 'جامدادی' },
                    { id: 'pencil', label: 'خودکار و مداد' },
                    { id: 'notebook', label: 'دفتر' },
                    { id: 'geometry', label: 'هندسی' },
                    { id: 'marker', label: 'نقاشی' },
                    { id: 'decorative', label: 'تزئینی' },
                  ].map(category => (
                    <button
                      key={category.id}
                      onClick={() => setSelectedFilter(category.id)}
                      className={`px-6 py-2 rounded-full font-medium transition-all duration-300 ${
                        selectedFilter === category.id
                          ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-lg'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {category.label}
                    </button>
                  ))}
                </div>
              </div>
            </section>
          </FadeIn>

          <ProductGrid 
            selectedFilter={selectedFilter}
            onAddToCart={handleAddToCart}
          />

          <SlideUp delay={400}>
            <section className="py-16 bg-gradient-to-r from-pink-50 to-purple-50">
              <div className="container mx-auto px-4">
                <div className="text-center">
                  <h2 className="text-4xl font-bold text-gray-800 mb-4">
                    <span className="bg-gradient-to-r from-pink-500 to-purple-600 bg-clip-text text-transparent">
                      چرا علیزاده؟
                    </span>
                  </h2>
                  <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-12">
                    ما بهترین محصولات لوازم‌تحریر فانتزی و پاستیلی را برای شما فراهم می‌کنیم
                  </p>
                  <div className="grid md:grid-cols-3 gap-8">
                    {[
                      { icon: '✨', title: 'کیفیت بالا', desc: 'محصولات با کیفیت و دوام بالا' },
                      { icon: '🎨', title: 'طرح‌های منحصر', desc: 'طرح‌های منحصر به فرد و جذاب' },
                      { icon: '💝', title: 'قیمت مناسب', desc: 'قیمت‌های رقابتی و مناسب' },
                    ].map((item, idx) => (
                      <div key={idx} className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300">
                        <div className="text-4xl mb-4">{item.icon}</div>
                        <h3 className="text-xl font-bold text-gray-800 mb-2">{item.title}</h3>
                        <p className="text-gray-600">{item.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </section>
          </SlideUp>

          <ContactForm />
        </main>

        <Footer />
      </div>
    </div>
  );
}
