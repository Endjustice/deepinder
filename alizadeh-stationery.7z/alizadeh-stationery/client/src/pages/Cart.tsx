import React, { useState, useEffect } from 'react';
import { Trash2, Plus, Minus, ShoppingCart, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ScrollProgressBar from '@/components/ScrollProgressBar';

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  image?: string;
}

export default function Cart() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Load cart from localStorage on mount
  useEffect(() => {
    const savedCart = localStorage.getItem('alizadeh-cart');
    if (savedCart) {
      setCart(JSON.parse(savedCart));
    }
    setIsLoading(false);
  }, []);

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('alizadeh-cart', JSON.stringify(cart));
  }, [cart]);

  const handleIncreaseQuantity = (id: number) => {
    setCart(cart.map(item =>
      item.id === id
        ? { ...item, quantity: item.quantity + 1 }
        : item
    ));
  };

  const handleDecreaseQuantity = (id: number) => {
    setCart(cart.map(item =>
      item.id === id && item.quantity > 1
        ? { ...item, quantity: item.quantity - 1 }
        : item
    ));
  };

  const handleRemoveItem = (id: number) => {
    setCart(cart.filter(item => item.id !== id));
  };

  const handleClearCart = () => {
    if (window.confirm('آیا می‌خواهید تمام محصولات را حذف کنید؟')) {
      setCart([]);
    }
  };

  const totalPrice = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white">
        <Header cartCount={totalItems} />
        <div className="flex items-center justify-center py-20">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-pink-200 border-t-pink-500 rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600">در حال بارگذاری...</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <ScrollProgressBar />
      <Header cartCount={totalItems} />

      <main className="container mx-auto px-4 py-16">
        {/* Page Title */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <ShoppingCart className="w-8 h-8 text-pink-500 ml-2" />
            <h1 className="text-4xl font-bold text-gray-800">
              <span className="bg-gradient-to-r from-pink-500 to-purple-600 bg-clip-text text-transparent">
                سبد خرید
              </span>
            </h1>
          </div>
          <p className="text-lg text-gray-600">
            {totalItems === 0
              ? 'سبد خرید شما خالی است'
              : `شما ${totalItems} محصول در سبد خرید دارید`}
          </p>
        </div>

        {cart.length === 0 ? (
          // Empty Cart
          <div className="text-center py-20">
            <div className="mb-8">
              <ShoppingCart className="w-20 h-20 text-gray-300 mx-auto" />
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-4">سبد خرید خالی است</h2>
            <p className="text-gray-600 mb-8">
              هنوز هیچ محصولی به سبد خرید اضافه نکرده‌اید
            </p>
            <Link href="/">
              <Button className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white px-8 py-3 rounded-full text-lg font-medium shadow-lg hover:shadow-xl transition-all duration-300">
                <ArrowRight className="w-5 h-5 ml-2" />
                بازگشت به فروشگاه
              </Button>
            </Link>
          </div>
        ) : (
          // Cart Items
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Cart Items List */}
            <div className="lg:col-span-2 space-y-4">
              {cart.map(item => (
                <div
                  key={item.id}
                  className="bg-white border border-pink-100 rounded-2xl p-6 hover:shadow-lg transition-all duration-300"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-800 mb-2">
                        {item.name}
                      </h3>
                      <p className="text-lg font-bold text-pink-600">
                        {item.price.toLocaleString('fa-IR')} تومان
                      </p>
                    </div>
                    <button
                      onClick={() => handleRemoveItem(item.id)}
                      className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                      title="حذف محصول"
                    >
                      <Trash2 className="w-6 h-6" />
                    </button>
                  </div>

                  {/* Quantity Controls */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 bg-gray-100 rounded-lg p-2">
                      <button
                        onClick={() => handleDecreaseQuantity(item.id)}
                        className="p-2 text-gray-600 hover:text-pink-500 transition-colors"
                        title="کاهش تعداد"
                      >
                        <Minus className="w-5 h-5" />
                      </button>
                      <span className="w-8 text-center font-bold text-gray-800">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => handleIncreaseQuantity(item.id)}
                        className="p-2 text-gray-600 hover:text-pink-500 transition-colors"
                        title="افزایش تعداد"
                      >
                        <Plus className="w-5 h-5" />
                      </button>
                    </div>

                    <div className="text-right">
                      <p className="text-sm text-gray-600 mb-1">جمع</p>
                      <p className="text-xl font-bold text-purple-600">
                        {(item.price * item.quantity).toLocaleString('fa-IR')} تومان
                      </p>
                    </div>
                  </div>
                </div>
              ))}

              {/* Clear Cart Button */}
              <div className="text-center pt-4">
                <button
                  onClick={handleClearCart}
                  className="text-red-500 hover:text-red-700 font-medium transition-colors"
                >
                  حذف تمام محصولات
                </button>
              </div>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="bg-gradient-to-br from-pink-50 to-purple-50 rounded-2xl p-8 sticky top-20">
                <h2 className="text-2xl font-bold text-gray-800 mb-6">خلاصه سفارش</h2>

                <div className="space-y-4 mb-6 pb-6 border-b border-pink-200">
                  <div className="flex justify-between">
                    <span className="text-gray-600">تعداد محصولات:</span>
                    <span className="font-bold text-gray-800">{totalItems}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">قیمت کل:</span>
                    <span className="font-bold text-gray-800">
                      {totalPrice.toLocaleString('fa-IR')} تومان
                    </span>
                  </div>
                </div>

                {/* Discount Info */}
                <div className="bg-white rounded-lg p-4 mb-6 border border-pink-200">
                  <p className="text-sm text-gray-600 mb-2">
                    <span className="font-bold text-pink-500">تخفیف:</span> 0 تومان
                  </p>
                  <p className="text-sm text-gray-600">
                    <span className="font-bold text-pink-500">هزینه ارسال:</span> رایگان
                  </p>
                </div>

                {/* Total */}
                <div className="bg-white rounded-lg p-4 mb-6 border-2 border-pink-300">
                  <p className="text-gray-600 mb-2">مبلغ نهایی</p>
                  <p className="text-3xl font-bold text-pink-600">
                    {totalPrice.toLocaleString('fa-IR')}
                  </p>
                  <p className="text-sm text-gray-500 mt-1">تومان</p>
                </div>

                {/* Checkout Button */}
                <Button
                  className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white rounded-full py-3 text-lg font-medium shadow-lg hover:shadow-xl transition-all duration-300 mb-4"
                  onClick={() => {
                    alert('درگاه پرداخت به زودی فعال خواهد شد. برای اطلاعات بیشتر با ما تماس بگیرید: 09126909560');
                  }}
                >
                  ادامه خرید
                </Button>

                {/* Continue Shopping */}
                <Link href="/">
                  <Button
                    variant="outline"
                    className="w-full border-2 border-pink-300 text-pink-600 hover:bg-pink-50 rounded-full py-3 text-lg font-medium"
                  >
                    بازگشت به فروشگاه
                  </Button>
                </Link>

                {/* Info Box */}
                <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-800">
                    <span className="font-bold">ℹ️ نکته:</span> سبد خرید شما در دستگاه محفوظ است و تا زمانی که حذف نکنید باقی خواهد ماند.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
